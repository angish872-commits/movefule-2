# MoveFuel

Canonical MoveFuel repository.

This repository contains the audited nutrition intelligence and training engine packages plus integration documentation.

## Structure

- `algorithms/nutrition/` — MoveFuel Nutrition Intelligence NEXT RC
- `algorithms/training/` — MoveFuel Training Engine FINAL 180 Checklist package
- `docs/ALGORITHM_INTEGRATION_REPORT.md` — integration status, architecture, test evidence, and next steps

> Safety note: MoveFuel is a non-medical fitness and nutrition product. Algorithmic recommendations must preserve the safety gates in the source packages and must not be presented as diagnosis or medical treatment.
