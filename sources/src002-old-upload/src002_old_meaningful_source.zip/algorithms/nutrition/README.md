# MoveFuel Nutrition Intelligence — NEXT RC

Standalone nutrition/dieting intelligence engine focused on:
- verified food/nutrient data boundaries
- youth-safe nutrition policy and separate adult-only weight-management policy
- allergy/dietary hard constraints
- nutrient calculations with unknown-data preservation
- food knowledge graph and provenance
- probabilistic meal-photo contracts and uncertainty
- expected-information-gain clarification
- cultural/regional/seasonal context without identity inference
- budget, pantry, grocery and food-waste optimization
- multi-objective meal ranking and weekly planning
- behavior-based personalization after hard safety filtering
- strict structured AI contracts
- Appwrite TablesDB schema manifest
- evaluation, shadow mode, algorithm/model registry
- automated tests, simulation and release validation

This is an engineering release candidate, not medical care or a substitute for a registered dietitian/clinician. Real production release still requires live data ingestion, expert review, device/backend deployment, labeled evaluation datasets, security/load testing and longitudinal user validation.
