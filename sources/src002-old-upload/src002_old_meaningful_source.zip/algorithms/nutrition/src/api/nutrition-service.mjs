import {rankMealCandidates,recommendationViews} from '../planning/recommendation-engine.mjs';
import {buildWeeklyPlan,planStats} from '../planning/weekly-planner.mjs';
import {calculateMealNutrition} from '../science/nutrient-engine.mjs';
import {getNutritionAgePolicy} from '../safety/age-policy.mjs';
export class NutritionService{
 constructor({foodGraph,recipes=[],prices=[]}){this.foodGraph=foodGraph;this.recipes=recipes;this.prices=prices;}
 foodLookup=(id)=>this.foodGraph.get(id);
 calculateMeal(items){return calculateMealNutrition(items,this.foodLookup);}
 recommend(input){const ranked=rankMealCandidates({...input,recipes:this.recipes,foodLookup:this.foodLookup,prices:this.prices});return {ranked,views:recommendationViews(ranked),agePolicy:getNutritionAgePolicy(input.profile.age)};}
 planWeek(input){const plan=buildWeeklyPlan({...input,recipes:this.recipes,foodLookup:this.foodLookup,prices:this.prices});return {plan,stats:planStats(plan)};}
}
