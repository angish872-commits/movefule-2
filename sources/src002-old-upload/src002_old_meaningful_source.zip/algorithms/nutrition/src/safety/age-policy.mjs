import {AGE_BANDS} from '../domain/constants.mjs';
export function ageBandFromAge(age){ if(!Number.isFinite(age)||age<0) throw new Error('INVALID_AGE'); if(age<18) return AGE_BANDS.YOUTH; if(age<65) return AGE_BANDS.ADULT; return AGE_BANDS.OLDER_ADULT; }
export function getNutritionAgePolicy(age){
 const band=ageBandFromAge(age);
 if(band===AGE_BANDS.YOUTH) return Object.freeze({band,allowCalorieDeficitTarget:false,allowRapidWeightChange:false,allowFastingPrescription:false,allowMealSkippingGoal:false,allowWeightLossGamification:false,focus:['MEAL_REGULARITY','ADEQUACY','VARIETY','FOOD_SKILLS','HYDRATION','AFFORDABILITY']});
 return Object.freeze({band,allowCalorieDeficitTarget:true,allowRapidWeightChange:false,allowFastingPrescription:false,allowMealSkippingGoal:false,allowWeightLossGamification:false,focus:['ADEQUACY','BALANCE','MODERATION','DIVERSITY','PREFERENCE','AFFORDABILITY']});
}
export function enforceYouthSafeGoal(age, goal){ const p=getNutritionAgePolicy(age); const blocked=['CALORIE_DEFICIT','RAPID_WEIGHT_LOSS','FASTING','MEAL_SKIPPING'].includes(goal); return {allowed:!(p.band==='YOUTH'&&blocked),policy:p,reasonCode:p.band==='YOUTH'&&blocked?'YOUTH_RESTRICTIVE_GOAL_BLOCKED':'AGE_POLICY_PASS'}; }
