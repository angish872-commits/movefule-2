import {recipeAllergenStatus} from './allergen-engine.mjs';
import {recipeDietStatus, assertRulesAreUserDeclared} from './dietary-rules.mjs';
import {enforceYouthSafeGoal} from './age-policy.mjs';
export function hardRecommendationGate({profile,foods,goal='GENERAL_NUTRITION'}){
 assertRulesAreUserDeclared(profile);
 const age=enforceYouthSafeGoal(profile.age,goal); if(!age.allowed) return {pass:false,reasonCodes:[age.reasonCode],age};
 const allergy=recipeAllergenStatus(profile,foods); if(!allergy.pass) return {pass:false,reasonCodes:allergy.reasonCodes,allergy,age};
 const diet=recipeDietStatus(profile,foods); if(!diet.pass) return {pass:false,reasonCodes:diet.reasonCodes,diet,allergy,age};
 return {pass:true,reasonCodes:['HARD_SAFETY_GATE_PASS'],age,allergy,diet};
}
