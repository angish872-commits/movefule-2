// MoveFuel Training Engine 5.x — deterministic core.
// Public facade: keep imports stable when integrating this branch into the main MoveFuel repository.

export * from "./types";
export * from "./profile";
export * from "./readiness";
export * from "./goal-policy";
export * from "./exercise-library";
export * from "./safety";
export * from "./calendar";
export * from "./missed-workout";
export * from "./recovery";
export * from "./state";
export * from "./movement-balance";
export * from "./candidate-filter";
export * from "./scoring";
export * from "./continuity";
export * from "./progression";
export * from "./equipment-adaptation";
export * from "./time-adaptation";
export * from "./session-generator";
export * from "./validator";
export * from "./explanation";
export * from "./openrouter-explanation";
export * from "./watch";
export * from "./watch-executor";
export * from "./watch-storage";
export * from "./ui-contracts";
export * from "./completion";
export * from "./learning";
export * from "./calendar-management";
export * from "./adherence-learning";
export * from "./nutrition-boundary";
export * from "./adapt-today";
export * from "./exercise-knowledge";
export * from "./watch-execution-storage";
export * from "./benchmark";
export * from "./integration-gates";
export * from "./telemetry";
export * from "./safety-contract";

import { CalendarDayInput, CalendarRevision, ExerciseDefinition, ReadinessInput, TrainingHistory, TrainingPlan, TrainingProfile, ValidationResult } from "./types";
import { DEFAULT_EXERCISE_LIBRARY } from "./exercise-library";
import { validateAndNormalizeProfile } from "./profile";
import { calculateReadiness } from "./readiness";
import { getBlendedGoalPolicy } from "./goal-policy";
import { buildTrainingState } from "./state";
import { capTrainingFrequency } from "./safety";
import { optimizeCalendar } from "./calendar";
import { generateSession } from "./session-generator";
import { adaptSessionToTime } from "./time-adaptation";
import { validateTrainingPlan } from "./validator";
import { stableHash } from "./util";

export interface GenerateTrainingPlanInput {
  profile: TrainingProfile;
  readiness: ReadinessInput;
  history: TrainingHistory;
  calendarDays: CalendarDayInput[];
  now: string;
  programRevision?: number;
  executionRevision?: number;
  library?: ExerciseDefinition[];
}

export interface GenerateTrainingPlanResult {
  plan?: TrainingPlan;
  validation?: ValidationResult;
  errors: string[];
}

function normalizePlanSetBudget(sessions: import("./types").TrainingSession[], maxWeeklySets: number): import("./types").TrainingSession[] {
  const out = sessions.map((session) => ({...session, exercises:session.exercises.map((e)=>({ ...e, decisionReasons:[...e.decisionReasons] })), explanationEvidence:[...session.explanationEvidence]}));
  const total = () => out.reduce((sum,s)=>sum+s.exercises.reduce((x,e)=>x+e.sets,0),0);
  const ranks: Array<import("./types").ExercisePrescription["priority"]> = ["ACCESSORY","SECONDARY","PRIMARY"];
  let guard=0;
  while (total() > maxWeeklySets && guard++ < 10000) {
    let changed=false;
    for (const priority of ranks) {
      for (let si=out.length-1;si>=0 && total()>maxWeeklySets;si-=1) {
        const candidates=[...out[si].exercises].reverse().filter((e)=>e.priority===priority && e.sets>1);
        for (const e of candidates) {
          if (total()<=maxWeeklySets) break;
          e.sets-=1; e.decisionReasons.push("WEEKLY_SET_BUDGET_NORMALIZED"); changed=true;
        }
      }
      if (total()<=maxWeeklySets) break;
    }
    if (!changed) break;
  }
  return out;
}

export function generateTrainingPlan(input: GenerateTrainingPlanInput): GenerateTrainingPlanResult {
  const profileResult = validateAndNormalizeProfile(input.profile);
  if (!profileResult.valid || !profileResult.normalized) return { errors: profileResult.errors };
  const profile = profileResult.normalized;
  const library = input.library ?? DEFAULT_EXERCISE_LIBRARY;
  const readiness = calculateReadiness(input.readiness);
  if (readiness.status === "STOP") return { errors: ["READINESS_STOP"] };
  const policy = getBlendedGoalPolicy(profile.primaryGoal, profile.secondaryGoal, profile.ageBand);
  const state = buildTrainingState(input.history, input.now, library, profile.ageBand, profile.externalActivities);
  const preparedCalendarDays = input.calendarDays.map((d) => ({...d, available:d.available && profile.availableDays.includes(d.weekday), availableMinutes:Math.min(d.availableMinutes, profile.availableTimeByDay[d.weekday] ?? d.availableMinutes, profile.maxSessionMinutes), locked:d.locked || profile.lockedTrainingDays.includes(d.weekday), preferredRest:d.preferredRest || profile.preferredRestDays.includes(d.weekday), externalActivities:[...d.externalActivities, ...profile.externalActivities.filter((a)=>a.day===d.weekday)]}));
  const frequency = capTrainingFrequency(profile, policy);
  const calendar = optimizeCalendar(preparedCalendarDays, frequency.allowedFrequency, profile, state);
  if (!calendar.valid) return { errors: calendar.errors };
  const calendarRevision: CalendarRevision = { revision:1, createdAt:input.now, reason:"INITIAL", sessions:calendar.sessions };
  const warnings=[...frequency.reasons];
  const sessions: import("./types").TrainingSession[]=[];
  for (let i=0;i<calendar.sessions.length;i+=1) {
    const cal=calendar.sessions[i];
    const generated=generateSession({scheduledDate:cal.date,calendarState:cal.state,availableMinutes:Math.min(cal.availableMinutes,profile.maxSessionMinutes),profile,policy,state,readiness,library,sequence:i,externalActivities:preparedCalendarDays.find((d)=>d.date===cal.date)?.externalActivities ?? []});
    warnings.push(...generated.warnings);
    if (generated.session) sessions.push(adaptSessionToTime(generated.session,Math.min(cal.availableMinutes,profile.maxSessionMinutes)));
  }
  const normalizedSessions=normalizePlanSetBudget(sessions, profile.ageBand === "YOUTH" || policy.goal === "RETURN_TO_TRAINING" ? 48 : 90);
  const plan: TrainingPlan={planId:`plan_${stableHash(`${profile.userId}|${input.now}|${input.programRevision ?? 1}`)}`,userId:profile.userId,programRevision:input.programRevision ?? 1,executionRevision:input.executionRevision ?? 1,calendarRevision,sessions:normalizedSessions,generatedAt:input.now,warnings:[...new Set(warnings)]};
  const availableDaysByDate=Object.fromEntries(preparedCalendarDays.map((d)=>[d.date,{available:d.available,minutes:d.availableMinutes,locked:d.locked}]));
  const validation=validateTrainingPlan(plan,{profile,policy,state,library,availableDaysByDate});
  if (!validation.valid) return {plan,validation,errors:validation.issues.filter((i)=>i.severity==="ERROR").map((i)=>`${i.code}:${i.message}`)};
  return {plan,validation,errors:[]};
}
