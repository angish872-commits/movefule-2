import { NutritionTrainingBoundaryInput, NutritionTrainingBoundaryResult } from "./types";

/** Non-medical safety boundary between nutrition and training. */
export function validateNutritionTrainingBoundary(input: NutritionTrainingBoundaryInput): NutritionTrainingBoundaryResult {
  const reasons: string[] = [];
  if (input.missedNutritionTarget) reasons.push("NUTRITION_TARGET_DOES_NOT_TRIGGER_PUNISHMENT_TRAINING");
  if (input.underFuelingSignal) reasons.push("UNDER_FUELING_SIGNAL_BLOCKS_AUTOMATIC_TRAINING_INCREASE");
  const allowHarderTraining = Boolean(input.requestedTrainingIncrease) && !input.underFuelingSignal && !input.missedNutritionTarget;
  if (input.requestedTrainingIncrease && !allowHarderTraining) reasons.push("HARDER_TRAINING_NOT_JUSTIFIED_BY_NUTRITION_SIGNAL");
  return { allowHarderTraining, reasons };
}
