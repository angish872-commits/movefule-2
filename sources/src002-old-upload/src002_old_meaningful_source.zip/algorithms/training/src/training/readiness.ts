import { ReadinessInput, ReadinessResult } from "./types";
import { clamp, mean } from "./util";

export function calculateReadiness(input: ReadinessInput): ReadinessResult {
  if (input.painFlag || input.illnessFlag) return {score:0,status:"STOP",volumeMultiplier:0,confidence:"HIGH",reasons:[input.painFlag ? "PAIN_FLAG" : "ILLNESS_FLAG"]};
  const values:number[]=[];
  if (typeof input.sleepQuality === "number") values.push(clamp(input.sleepQuality / 10));
  if (typeof input.energy === "number") values.push(clamp(input.energy / 10));
  if (typeof input.motivation === "number") values.push(clamp(input.motivation / 10));
  if (typeof input.soreness === "number") values.push(clamp((10-input.soreness)/10));
  if (!values.length) return {score:null,status:"REDUCED",volumeMultiplier:0.85,confidence:"LOW",reasons:["NO_READINESS_DATA"]};
  const normalized=mean(values)!; const score=Math.round(normalized*100);
  if (normalized >= 0.75) return {score,status:"FULL",volumeMultiplier:1,confidence:values.length>=3?"HIGH":"MEDIUM",reasons:["GOOD_SELF_REPORTED_READINESS"]};
  if (normalized >= 0.55) return {score,status:"REDUCED",volumeMultiplier:0.85,confidence:values.length>=3?"HIGH":"MEDIUM",reasons:["MODERATE_SELF_REPORTED_READINESS"]};
  return {score,status:"RECOVERY",volumeMultiplier:0.6,confidence:values.length>=3?"HIGH":"MEDIUM",reasons:["LOW_SELF_REPORTED_READINESS"]};
}
