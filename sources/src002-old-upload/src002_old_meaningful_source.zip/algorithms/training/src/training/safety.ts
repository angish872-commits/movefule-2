import { ExerciseDefinition, GoalPolicy, RecoveryStatus, TrainingProfile, TrainingState } from "./types";

const experienceRank = { BEGINNER: 0, INTERMEDIATE: 1, ADVANCED: 2 } as const;

export interface HardConstraintResult { allowed: boolean; reasons: string[]; }

export function validateExerciseHardConstraints(exercise: ExerciseDefinition, profile: TrainingProfile, policy: GoalPolicy, recoveryStatus: RecoveryStatus = "UNCERTAIN"): HardConstraintResult {
  const reasons: string[] = [];
  if (profile.avoidedExerciseIds.includes(exercise.id) || (profile.blockedExerciseIds ?? []).includes(exercise.id)) reasons.push("USER_RESTRICTION");
  const equipment = new Set(profile.equipment);
  const missing = exercise.equipment.filter((e) => !equipment.has(e));
  if (missing.length) reasons.push(`MISSING_EQUIPMENT:${missing.join(",")}`);
  if (!exercise.locations.includes(profile.trainingLocation) && profile.trainingLocation !== "MIXED") reasons.push("LOCATION_INCOMPATIBLE");
  if (experienceRank[exercise.difficulty] > experienceRank[profile.experience]) reasons.push("EXPERIENCE_TOO_LOW");
  if (experienceRank[exercise.difficulty] > experienceRank[policy.maxExerciseComplexity]) reasons.push("POLICY_COMPLEXITY_LIMIT");
  const movementSkill = profile.movementSkill?.[exercise.movement];
  if (exercise.highSkill && movementSkill === "NOVICE") reasons.push("MOVEMENT_SKILL_TOO_LOW");
  if (profile.ageBand === "YOUTH") {
    if (!exercise.youthSafe) reasons.push("YOUTH_UNSAFE");
    if (exercise.highSkill && profile.experience === "BEGINNER") reasons.push("YOUTH_HIGH_SKILL_BEGINNER");
  }
  if (recoveryStatus === "LOW" && exercise.fatigueCost >= 0.75) reasons.push("LOW_RECOVERY_HIGH_FATIGUE");
  return { allowed: reasons.length === 0, reasons };
}

export function capTrainingFrequency(profile: TrainingProfile, policy: GoalPolicy) {
  let allowed = Math.min(profile.preferredTrainingFrequency, policy.weeklyFrequencyRange[1]);
  const reasons: string[]=[];
  if (profile.ageBand === "YOUTH" && allowed > 4) { allowed = 4; reasons.push("YOUTH_FREQUENCY_CAP"); }
  if (profile.experience === "BEGINNER" && allowed > 4) { allowed = 4; reasons.push("BEGINNER_FREQUENCY_CAP"); }
  return { allowedFrequency: Math.max(1, allowed), reasons };
}

export function validateRecentWorkload(state: TrainingState, policy: GoalPolicy): string[] {
  const issues: string[]=[];
  const total=state.weeklyExposure.totalSets;
  const maxTotal=policy.goal === "RETURN_TO_TRAINING" || policy.goal === "YOUTH_FOUNDATION" ? 48 : 80;
  if (total > maxTotal) issues.push("RECENT_WEEKLY_VOLUME_HIGH");
  const ratio=state.weeklyExposure.workloadChangeRatio;
  if (ratio !== null && ratio !== undefined && ratio > 1.5 && total >= 12) issues.push("SUDDEN_WORKLOAD_INCREASE");
  return issues;
}
