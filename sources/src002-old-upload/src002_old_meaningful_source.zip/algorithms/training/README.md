# MoveFuel Training Engine 5.x

Deterministic training engine for MoveFuel covering training-plan generation, whole-week calendar optimization, readiness/recovery, safety constraints, progression, exercise filtering/scoring, time/equipment adaptation, watch execution contracts, completion and learning.

Important boundary: this is evidence-informed non-medical software. Pain/illness flags stop automatic generation rather than attempting diagnosis or treatment. Numeric guardrails remain explicit and calibratable.

Audited source-package baseline: 80/80 behavioral tests passing and 144/144 deterministic benchmark personas.

The stable facade is `src/training/training-engine.ts`.
