# MoveFuel Algorithm Integration Report

Date: 2026-08-29
Repository: `angish872-commits/movefule`
Branch: `main`

## 1. Repository state before work

The connected GitHub repository existed but its `main` branch had no project files. There was therefore no Android/backend code in GitHub to merge against. The safe approach was to establish a canonical algorithm area rather than pretending the engines had already been wired into a missing application.

## 2. Source packages audited

### Nutrition
Source package: `MoveFuel_Nutrition_Intelligence_NEXT_RC.zip`

Audited release evidence from the package:
- 307 automated tests passed, 0 failed.
- 50,000 synthetic safety-simulation cases, 0 detected hard-rule violations.
- 112 registered exports.
- 2,028 checklist items.
- Appwrite design inventory: 14 logical databases / 237 tables.
- Scope is nutrition/dieting intelligence; production validation is still required.

### Training
Source package: `MoveFuel_Training_Engine_v1_FINAL_180_CHECKLIST.zip`, cross-checked against the integrated Training Engine 5 package.

Audited release evidence from the source package:
- 80/80 behavioral tests passed.
- 144/144 deterministic benchmark personas generated valid plans.
- Deterministic training prescriptions: LLM is not allowed to author the workout prescription.
- Calendar, progression, recovery/readiness, equipment filtering, youth policy and phone/watch contracts exist in the source package.

## 3. What was added to GitHub

The repository now has a canonical layout:

```text
algorithms/
  nutrition/
    package.json
    README.md
    src/api/nutrition-service.mjs
    src/safety/age-policy.mjs
    src/safety/recommendation-gate.mjs
  training/
    package.json
    README.md
    src/training/training-engine.ts
    src/training/nutrition-boundary.ts
    src/training/safety.ts
    src/training/readiness.ts

docs/
  ALGORITHM_INTEGRATION_REPORT.md
```

These committed files establish the stable API/facade, core safety gates, readiness behavior and the nutrition↔training boundary. The original audited packages remain the source of truth for the additional modules and tests until the full application repository is present and all dependencies are mirrored into GitHub.

## 4. Required architecture when the MoveFuel application code is pushed

Do not put algorithm math inside Compose screens, ViewModels, Wear screens or Appwrite Functions independently. Use a single domain boundary.

Recommended flow:

```text
User profile / preferences / history
        |
        +--------------------+
        |                    |
Nutrition Engine        Training Engine
        |                    |
        | safety context     | calendar/progression
        +---------> Integration Boundary
                         |
                  App domain contracts
                         |
        +----------------+----------------+
        |                                 |
 Android phone                     Wear OS / watch
        |                                 |
 Appwrite persistence <---- sync/revisions ---->
```

## 5. Nutrition integration contract

The application should call a service/repository adapter around `NutritionService`; UI code should not recalculate nutrient totals or safety rules.

Inputs should include, as applicable:
- explicit user age / age band
- user-declared dietary rules
- user-declared allergens
- food/recipe identifiers and serving amounts
- regional/seasonal context when voluntarily configured
- confirmed meal corrections
- budget/pantry constraints

Outputs should preserve:
- numeric ranges rather than false precision where uncertainty exists
- data source / provenance
- unknown != zero
- safety state and suppression reason
- evidence/confidence where available

AI may explain or rephrase an approved recommendation, but must not silently change calories, macro values, allergen rules, safety state or deterministic recommendation category.

## 6. Training integration contract

The main application should treat `generateTrainingPlan(...)` as the stable plan-generation boundary.

Primary data mapping required from the app:
- profile -> `TrainingProfile`
- workout history -> `TrainingHistory`
- calendar availability -> `CalendarDayInput[]`
- readiness -> `ReadinessInput`
- exercise catalog -> `ExerciseDefinition[]`

Returned `TrainingPlan` must then be revisioned, persisted and published to phone/watch state rather than regenerated independently by the UI.

## 7. Nutrition ↔ training boundary

This is a critical safety rule and must remain explicit.

Current boundary guarantees:
- missing/missed nutrition targets do not create punishment workouts;
- an under-fueling signal cannot automatically increase training difficulty;
- a harder-training request is permitted by this boundary only when it is not being justified by missed nutrition or an under-fueling signal;
- nutrition and training remain separate deterministic decision systems joined by explicit contracts.

Do not implement rules such as:

`ate too much -> add cardio`

or

`missed calorie target -> harder workout`

Those would violate the current safety architecture.

## 8. Appwrite / persistence plan

When the real backend code is available, use adapters rather than importing Appwrite SDK calls directly into deterministic algorithm modules.

Recommended logical records:
- user nutrition profile / declared restrictions
- food log + correction history
- nutrition recommendation decision envelope
- training profile
- training program revision
- calendar revision
- workout session + set completion
- readiness inputs
- training decision/explanation evidence
- watch delivery receipt / reconciliation state

Every generated plan/recommendation should have a revision/id so stale phone/watch/backend messages cannot overwrite newer state.

## 9. Tests required after application integration

### Nutrition
- run the full 307-test package suite;
- rerun the 50,000-case safety simulation;
- test Appwrite food-data ingestion and provider failures;
- test unknown nutrient data, allergies and dietary-rule conflicts through the real app adapter;
- verify no API keys are bundled in Android/Wear artifacts.

### Training
- run full package tests and benchmark matrix;
- Android core/app unit tests;
- Room migration tests;
- Android lint;
- phone and Wear debug builds;
- missed-session rescheduling;
- progression after completed sets;
- equipment-change adaptation;
- disconnect/reconnect/reboot watch tests;
- duplicate/stale revision tests.

### Combined
- under-fueling signal never increases training difficulty;
- missed nutrition target never adds punishment exercise;
- account isolation;
- offline queue/replay;
- new user -> plan -> watch -> completion -> history -> next-plan loop.

## 10. What is NOT complete yet

Because the GitHub repository did not contain the actual Android/backend project, this commit does **not** claim:
- Android UI is already wired to the engines;
- Appwrite schemas are deployed;
- Wear OS physical delivery has been validated from this repository;
- every supporting module from both audited ZIPs has been mirrored into this GitHub repository;
- production scientific/clinical validation is complete.

The next repository milestone should be: push the current MoveFuel Android/backend source into this repo, then map existing domain models to these stable algorithm contracts and import the remaining audited source modules/tests without rewriting them.

## 11. Recommended final target

The system should only be considered integrated when this continuous loop works:

`Profile -> Nutrition -> Training -> Calendar -> Phone -> Watch -> Offline execution -> Sync -> History -> Progression -> Next nutrition/training decision`

with deterministic safety gates preserved throughout.
